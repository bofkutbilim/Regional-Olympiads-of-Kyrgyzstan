#include <stdio.h>
#include <queue>

int main(){
    int a,b;
    scanf("%d %d",&a,&b);
    int d[100000];
    for (int i = 0; i < 100000; i++)
        d[i] = 1000000000;
    std::queue<int>q;
    q.push(a);
    d[a] = 0;
    while (!q.empty()) {
        int v = q.front();
        q.pop();
        if (v == b)
            return printf("%d", d[b]),0;
        for (int i = 1; i < v; i++) {
            if (v % i == 0 && d[i] == 1000000000) {
                d[i] = d[v] + 1;
                q.push(i);
            }
        }
        if (v - 1 >= 1 && d[v-1] == 1000000000) {
            d[v-1] = d[v] + 1;
            q.push(v-1);
        }
        if (d[v+1] == 1000000000) {
            d[v+1] = d[v] + 1;
            q.push(v+1);
        }
    }
    return 0;
}
