#include <bits/stdc++.h>

using namespace std;

const int n = 9, INF = 1000*1000*1000;
int d[n][n];
vector<vector<set<int>>> str(n, vector<set<int>> (n));
map<char, int> m;
vector<pair<int, int>> g[n];

enum{
	B = 0, A = 1, J = 2,
	T = 3, O = 4, K = 5,
	L = 6, N = 7, E = 8
};

void preparing(void) {
	
	m['B'] = 0; m['A'] = 1; m['J'] = 2;
	m['T'] = 3; m['O'] = 4; m['K'] = 5;
	m['L'] = 6; m['N'] = 7; m['E'] = 8;
	
	for (int i = 0; i < n; i++)
	for (int j = 0; j < n; j++)
		if (i != j) d[i][j] = INF;
	
	d[A][T] = d[T][A] = 102;
	d[A][J] = d[J][A] = 377;
	d[A][B] = d[B][A] = 193;
	d[J][O] = d[O][J] = 106;
	d[O][E] = d[E][O] = 240;
	d[L][B] = d[B][L] = 179;
	d[L][K] = d[K][L] = 216;
	d[L][N] = d[N][L] = 180;
	
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (d[i][j] == INF) continue;
			g[i].push_back({j, d[i][j]});
		}
	}
	
	for (int k = 0; k < n; k++)
	for (int i = 0; i < n; i++)
	for (int j = 0; j < n; j++)
		d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
	
	for (int i = 0; i < n; i++) {
		priority_queue<pair<int, int>> q;
		vector<int> dist(n, INF), p(n, -1), used(n, 0);
		q.push({0, i});
		dist[i] = 0;
		while (!q.empty()) {
			int v = q.top().second;
			q.pop();
			if (used[v] == 1)
				continue;
			used[v] = 1;
			for (auto i : g[v]) {
				int to = i.first, len = i.second;
				if (dist[v] + len < dist[to]) {
					dist[to] = dist[v] + len;
					p[to] = v;
					q.push({-dist[to], to});
				}
			}
		}
		
		for (int j = 0; j < n; j++) {
			if (i == j)
				continue;
			int v = j;
			while (v != -1) {
				str[i][j].insert(v);
				v = p[v];
			}
		}
	}
	
}

signed main(){
	preparing();
	
	int sz;
	cin >> sz;
	
	assert(sz > 0 && sz < 4);
	
	vector<pair<int, int>> thing(sz);
	
	for (int i = 0; i < sz; i++) {
		char a, b; cin >> a >> b;
		assert(m.count(a) == 1);
		assert(m.count(b) == 1);
		thing[i].first = m[a];
		thing[i].second = m[b];
	}
	
	function<void(int&,int)> update = [](int & ans, int res) {
		if (ans == -1 || res < ans)
			ans = res;
	};
	
	if (sz == 1) {
		cout << d[B][thing[0].first] + d[thing[0].first][thing[0].second] << '\n';
	} else if (sz == 2) {
		int p[] = {0, 1};
		int ans = -1;
		do{
			int a1 = thing[p[0]].first;
			int b1 = thing[p[0]].second;
			int a2 = thing[p[1]].first;
			int b2 = thing[p[1]].second;
			
			update(ans, d[B][a1]+d[a1][b1]+d[b1][a2]+d[a2][b2]);
			
			update(ans, d[B][a1]+d[a1][a2]+d[a2][b1]+d[b1][b2]);
			update(ans, d[B][a1]+d[a1][a2]+d[a2][b2]+d[b2][b1]);
			
		} while (next_permutation(p, p+2));
		
		assert(ans != -1);
		
		cout << ans << '\n';
	} else if (sz == 3) {
		int p[] = {0, 1, 2};
		int ans = -1;
		do{
			int a1 = thing[p[0]].first;
			int b1 = thing[p[0]].second;
			int a2 = thing[p[1]].first;
			int b2 = thing[p[1]].second;
			int a3 = thing[p[2]].first;
			int b3 = thing[p[2]].second;
			
			update(ans, d[B][a1]+d[a1][b1]+d[b1][a2]+d[a2][b2]+d[b2][a3]+d[a3][b3]);
			
			update(ans, d[B][a1]+d[a1][a2]+d[a2][b1]+d[b1][b2]+d[b2][a3]+d[a3][b3]);
			update(ans, d[B][a1]+d[a1][a2]+d[a2][b2]+d[b2][b1]+d[b1][a3]+d[a3][b3]);
			
			update(ans, d[B][a1]+d[a1][a2]+d[a2][b1]+d[b1][a3]+d[a3][b2]+d[b2][b3]);
			update(ans, d[B][a1]+d[a1][a2]+d[a2][b1]+d[b1][a3]+d[a3][b3]+d[b3][b2]);
			
			update(ans, d[B][a1]+d[a1][b1]+d[b1][a2]+d[a2][a3]+d[a3][b2]+d[b2][b3]);
			update(ans, d[B][a1]+d[a1][b1]+d[b1][a2]+d[a2][a3]+d[a3][b3]+d[b3][b2]);
			
			update(ans, d[B][a1]+d[a1][a2]+d[a2][b2]+d[b2][a3]+d[a3][b3]+d[b3][b1]);
			update(ans, d[B][a1]+d[a1][a2]+d[a2][b2]+d[b2][a3]+d[a3][b1]+d[b1][b3]);
			
			for (auto K : str[a1][a2])
				update(ans, d[B][a1]+d[a1][a2]+d[a2][a3]+d[a3][b2]+d[b2][b3]+d[b3][K]+d[K][b1]);
			for (auto K : str[a2][a3])
				update(ans, d[B][a1]+d[a1][a2]+d[a2][a3]+d[a3][b2]+d[b2][b3]+d[b3][K]+d[K][b1]);
			
			for (auto K : str[a2][a3]) {
				update(ans, d[B][a1]+d[a1][a2]+d[a2][a3]+d[a3][b3]+d[b3][b1]+d[b1][K]+d[K][b2]);
				update(ans, d[B][a1]+d[a1][a2]+d[a2][a3]+d[a3][b1]+d[b1][b3]+d[b3][K]+d[K][b2]);
			}
			
		} while (next_permutation(p, p+3));
		
		assert(ans != -1);
		
		cout << ans << '\n';
	}
	
	return 0;
}
