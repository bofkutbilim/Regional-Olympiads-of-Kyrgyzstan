#include <stdio.h>
#include <queue>
#include <map>
#include <functional>

int A[3000],Y[3000],S[3000];

int main(){
    int n;
    scanf("%d",&n);
    A[1] = 1; Y[1] = 1; S[1] = 0;
    A[2] = 2; Y[2] = 1; S[2] = 2;
    for (int i = 3; i <= n; i++){
        A[i] = S[i-1] + S[i-2] + 2;
        Y[i] = S[i-1] + 1;
        S[i] = A[i-1] + Y[i-1] + S[i-1];
        A[i] %= 1000; S[i] %= 1000;Y[i] %= 1000;
    }
    printf("%d",(A[n] + S[n] + Y[n])%1000);
    return 0;
}
