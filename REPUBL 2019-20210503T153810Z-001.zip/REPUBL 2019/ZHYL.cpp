#include <stdio.h>
#include <queue>
#include <map>
#include <functional>

int d[2020][2020];

int main(){
    int a, b;
    scanf("%d %d", &a, &b);
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    for (int i = 0; i < 2020; i++)
    for (int j = 0; j < 2020; j++)
        d[i][j] = 1000000000;
    std::queue<std::pair<int, int>>q;
    q.push({a,b});
    d[a][b] = 0;
    while (!q.empty()) {
        int x = q.front().first,y = q.front().second;
        q.pop();
        if (x == 0 && y == 0) break;
        for (int i = (x-5 > 0 ? x-5 : 0); i <= x; i++) {
            for (int j = (y-5 > 0 ? y-5 : 0); j <= y; j++) {
                if (d[i][j] == 1000000000) {
                    if ((i-x)*(i-x)+(j-y)*(j-y) <= 25){
                        q.push({i,j});
                        d[i][j] = d[x][y] + 1;
                    }
                }
            }
        }
    }
    printf("%d", d[0][0]);
    return 0;
}
