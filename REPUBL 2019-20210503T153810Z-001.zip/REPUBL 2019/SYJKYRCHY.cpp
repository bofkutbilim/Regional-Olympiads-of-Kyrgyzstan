#include <bits/stdc++.h>

using namespace std;

pair<int, int> f[20][20];
pair<int, int> s[20][20];

bool in(int x, int a, int b) {
	return x >= a && x <= b;
}

signed main() {
	
	int x1, y1, x2, y2;
	cin >> x1 >> y1 >> x2 >> y2;
	
	queue<pair<int,int>> q;
	q.push({x1,y1});
	map<pair<int, int>,int> dist;
	dist[{x1, y1}] = 0;
	map<pair<int, int>, pair<int, int>> p;
	
	while (!q.empty()) {
		int i = q.front().first, j = q.front().second;
		q.pop();
		if (in(i,0,19) && in(j,0,19)) {
			if (i-1 >= 00 && !dist.count({i-1,j}) && !(i == 10 && j <= 9)) {
				dist[{i-1, j}] = dist[{i, j}]+1;
				p[{i-1, j}] = make_pair(i,j);
				q.push({i-1, j});
			}
			if (i+1 <= 19 && !dist.count({i+1,j}) && !(i == 9 && j <= 9)) {
				dist[{i+1, j}] = dist[{i, j}]+1;
				p[{i+1, j}] = make_pair(i,j);
				q.push({i+1, j});
			}
			if (j-1 >= 00 && !dist.count({i,j-1})) {
				dist[{i, j-1}] = dist[{i, j}]+1;
				p[{i, j-1}] = make_pair(i,j);
				q.push({i, j-1});
			}
			if (j+1 <= 19 && !dist.count({i, j+1})) {
				dist[{i, j+1}] = dist[{i, j}]+1;	
				p[{i, j+1}] = make_pair(i,j);
				q.push({i, j+1});
			}
			if (i == 9 && j <= 9 && !dist.count({2010, 2000+j})) {
				dist[{2010, 2000+j}] = dist[{i, j}]+1;
				p[{2010, 2000+j}] = make_pair(i, j);
				q.push({2010, 2000+j});
			}
			if (i == 10 && j <= 9 && !dist.count({2009, 2000+j})) {
				dist[{2009, 2000+j}] = dist[{i, j}]+1;
				p[{2009, 2000+j}] = make_pair(i, j);
				q.push({2009, 2000+j});
			}
		}
		if (in(i,2000,2019) && in(j,2000,2019)){
			if (i-1 >= 2000 && !dist.count({i-1,j}) && !(i==2010 && j<=2009)) {
				dist[{i-1, j}] = dist[{i, j}]+1;
				p[{i-1, j}] = make_pair(i,j);
				q.push({i-1, j});
			}
			if (i+1 <= 2019 && !dist.count({i+1,j}) && !(i==2009 && j<=2009)) {
				dist[{i+1, j}] = dist[{i, j}]+1;
				p[{i+1, j}] = make_pair(i,j);
				q.push({i+1, j});
			}
			if (j-1 >= 2000 && !dist.count({i,j-1})) {
				dist[{i, j-1}] = dist[{i, j}]+1;
				p[{i, j-1}] = make_pair(i,j);
				q.push({i, j-1});
			}
			if (j+1 <= 2019 && !dist.count({i, j+1})) {
				dist[{i, j+1}] = dist[{i, j}]+1;
				p[{i, j+1}] = make_pair(i,j);
				q.push({i, j+1});
			}
			if (i==2009 && j<=2009 && !dist.count({10, j-2000})) {
				dist[{10, j-2000}] = dist[{i, j}]+1;
				p[{10, j-2000}] = make_pair(i, j);
				q.push({10, j-2000});
			}
			if (i==2010 && j<=2009 && !dist.count({9, j-2000})) {
				dist[{9, j-2000}] = dist[{i, j}]+1;
				p[{9, j-2000}] = make_pair(i, j);
				q.push({9, j-2000});
			}
		}
	}
	int i = x2, j = y2;
	cout << dist[{x2,y2}] << '\n';
	
	return 0;
}

