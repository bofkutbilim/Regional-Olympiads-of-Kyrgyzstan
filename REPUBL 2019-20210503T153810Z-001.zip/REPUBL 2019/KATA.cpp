#include <stdio.h>

int main() {
    int f[7],x,a,b,c,d;
    for (x = 1; x <= 6; x++) {
        scanf("%d",&f[x]);
    }
    for (a = 0; a <= 9; a++) {
        for (b = 0; b <= 9; b++) {
            for (c = 0; c <= 9; c++) {
                for (d = 0; d <= 9; d++) {
                    int cnt = 0;
                    for (x = 1; x <= 6; x++) {
                        if (f[x] == ((a*x + b)*x + c)*x + d) cnt++;
                    }
                    if (cnt == 5) {
                        printf("%d", a*1000 + b*100 + c*10 + d); return 0;
                    }
                }
            }
        }
    }
    return 0;
}

