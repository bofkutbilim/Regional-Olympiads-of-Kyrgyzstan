#include <bits/stdc++.h>

using namespace std;

int a[4], b[4];
const int INF = 1000000;

bool ZeroPar() {
    if (a[0]*a[1]*a[2]*a[3] == 24) return true;
    if (a[0]*a[1]*a[2]+a[3] == 24) return true;
    if (a[0]*a[1]*a[2]-a[3] == 24) return true;
    if (a[0]*a[1]+a[2]*a[3] == 24) return true;
    if (a[0]*a[1]+a[2]+a[3] == 24) return true;
    if (a[0]*a[1]+a[2]-a[3] == 24) return true;
    if (a[0]*a[1]-a[2]*a[3] == 24) return true;
    if (a[0]*a[1]-a[2]+a[3] == 24) return true;
    if (a[0]*a[1]-a[2]-a[3] == 24) return true;
    if (a[0]+a[1]*a[2]*a[3] == 24) return true;
    if (a[0]+a[1]*a[2]+a[3] == 24) return true;
    if (a[0]+a[1]*a[2]-a[3] == 24) return true;
    if (a[0]+a[1]+a[2]*a[3] == 24) return true;
    if (a[0]+a[1]+a[2]+a[3] == 24) return true;
    if (a[0]+a[1]+a[2]-a[3] == 24) return true;
    if (a[0]+a[1]-a[2]*a[3] == 24) return true;
    if (a[0]+a[1]-a[2]+a[3] == 24) return true;
    if (a[0]+a[1]-a[2]-a[3] == 24) return true;
    if (a[0]-a[1]*a[2]*a[3] == 24) return true;
    if (a[0]-a[1]*a[2]+a[3] == 24) return true;
    if (a[0]-a[1]*a[2]-a[3] == 24) return true;
    if (a[0]-a[1]+a[2]*a[3] == 24) return true;
    if (a[0]-a[1]+a[2]+a[3] == 24) return true;
    if (a[0]-a[1]+a[2]-a[3] == 24) return true;
    if (a[0]-a[1]-a[2]*a[3] == 24) return true;
    if (a[0]-a[1]-a[2]+a[3] == 24) return true;
    if (a[0]-a[1]-a[2]-a[3] == 24) return true;
    return false;
}

bool OnePar() {
    if ((a[0]*a[1])*a[2]*a[3] == 24) return true;
    if ((a[0]*a[1])*a[2]+a[3] == 24) return true;
    if ((a[0]*a[1])*a[2]-a[3] == 24) return true;
    if ((a[0]*a[1])+a[2]*a[3] == 24) return true;
    if ((a[0]*a[1])+a[2]+a[3] == 24) return true;
    if ((a[0]*a[1])+a[2]-a[3] == 24) return true;
    if ((a[0]*a[1])-a[2]*a[3] == 24) return true;
    if ((a[0]*a[1])-a[2]+a[3] == 24) return true;
    if ((a[0]*a[1])-a[2]-a[3] == 24) return true;
    if ((a[0]+a[1])*a[2]*a[3] == 24) return true;
    if ((a[0]+a[1])*a[2]+a[3] == 24) return true;
    if ((a[0]+a[1])*a[2]-a[3] == 24) return true;
    if ((a[0]+a[1])+a[2]*a[3] == 24) return true;
    if ((a[0]+a[1])+a[2]+a[3] == 24) return true;
    if ((a[0]+a[1])+a[2]-a[3] == 24) return true;
    if ((a[0]+a[1])-a[2]*a[3] == 24) return true;
    if ((a[0]+a[1])-a[2]+a[3] == 24) return true;
    if ((a[0]+a[1])-a[2]-a[3] == 24) return true;
    if ((a[0]-a[1])*a[2]*a[3] == 24) return true;
    if ((a[0]-a[1])*a[2]+a[3] == 24) return true;
    if ((a[0]-a[1])*a[2]-a[3] == 24) return true;
    if ((a[0]-a[1])+a[2]*a[3] == 24) return true;
    if ((a[0]-a[1])+a[2]+a[3] == 24) return true;
    if ((a[0]-a[1])+a[2]-a[3] == 24) return true;
    if ((a[0]-a[1])-a[2]*a[3] == 24) return true;
    if ((a[0]-a[1])-a[2]+a[3] == 24) return true;
    if ((a[0]-a[1])-a[2]-a[3] == 24) return true;
    if ((a[0]*a[1]*a[2])*a[3] == 24) return true;
    if ((a[0]*a[1]*a[2])+a[3] == 24) return true;
    if ((a[0]*a[1]*a[2])-a[3] == 24) return true;
    if ((a[0]*a[1]+a[2])*a[3] == 24) return true;
    if ((a[0]*a[1]+a[2])+a[3] == 24) return true;
    if ((a[0]*a[1]+a[2])-a[3] == 24) return true;
    if ((a[0]*a[1]-a[2])*a[3] == 24) return true;
    if ((a[0]*a[1]-a[2])+a[3] == 24) return true;
    if ((a[0]*a[1]-a[2])-a[3] == 24) return true;
    if ((a[0]+a[1]*a[2])*a[3] == 24) return true;
    if ((a[0]+a[1]*a[2])+a[3] == 24) return true;
    if ((a[0]+a[1]*a[2])-a[3] == 24) return true;
    if ((a[0]+a[1]+a[2])*a[3] == 24) return true;
    if ((a[0]+a[1]+a[2])+a[3] == 24) return true;
    if ((a[0]+a[1]+a[2])-a[3] == 24) return true;
    if ((a[0]+a[1]-a[2])*a[3] == 24) return true;
    if ((a[0]+a[1]-a[2])+a[3] == 24) return true;
    if ((a[0]+a[1]-a[2])-a[3] == 24) return true;
    if ((a[0]-a[1]*a[2])*a[3] == 24) return true;
    if ((a[0]-a[1]*a[2])+a[3] == 24) return true;
    if ((a[0]-a[1]*a[2])-a[3] == 24) return true;
    if ((a[0]-a[1]+a[2])*a[3] == 24) return true;
    if ((a[0]-a[1]+a[2])+a[3] == 24) return true;
    if ((a[0]-a[1]+a[2])-a[3] == 24) return true;
    if ((a[0]-a[1]-a[2])*a[3] == 24) return true;
    if ((a[0]-a[1]-a[2])+a[3] == 24) return true;
    if ((a[0]-a[1]-a[2])-a[3] == 24) return true;
    if (a[0]*(a[1]*a[2])*a[3] == 24) return true;
    if (a[0]*(a[1]*a[2])+a[3] == 24) return true;
    if (a[0]*(a[1]*a[2])-a[3] == 24) return true;
    if (a[0]*(a[1]+a[2])*a[3] == 24) return true;
    if (a[0]*(a[1]+a[2])+a[3] == 24) return true;
    if (a[0]*(a[1]+a[2])-a[3] == 24) return true;
    if (a[0]*(a[1]-a[2])*a[3] == 24) return true;
    if (a[0]*(a[1]-a[2])+a[3] == 24) return true;
    if (a[0]*(a[1]-a[2])-a[3] == 24) return true;
    if (a[0]+(a[1]*a[2])*a[3] == 24) return true;
    if (a[0]+(a[1]*a[2])+a[3] == 24) return true;
    if (a[0]+(a[1]*a[2])-a[3] == 24) return true;
    if (a[0]+(a[1]+a[2])*a[3] == 24) return true;
    if (a[0]+(a[1]+a[2])+a[3] == 24) return true;
    if (a[0]+(a[1]+a[2])-a[3] == 24) return true;
    if (a[0]+(a[1]-a[2])*a[3] == 24) return true;
    if (a[0]+(a[1]-a[2])+a[3] == 24) return true;
    if (a[0]+(a[1]-a[2])-a[3] == 24) return true;
    if (a[0]-(a[1]*a[2])*a[3] == 24) return true;
    if (a[0]-(a[1]*a[2])+a[3] == 24) return true;
    if (a[0]-(a[1]*a[2])-a[3] == 24) return true;
    if (a[0]-(a[1]+a[2])*a[3] == 24) return true;
    if (a[0]-(a[1]+a[2])+a[3] == 24) return true;
    if (a[0]-(a[1]+a[2])-a[3] == 24) return true;
    if (a[0]-(a[1]-a[2])*a[3] == 24) return true;
    if (a[0]-(a[1]-a[2])+a[3] == 24) return true;
    if (a[0]-(a[1]-a[2])-a[3] == 24) return true;
    if (a[0]*(a[1]*a[2]*a[3]) == 24) return true;
    if (a[0]*(a[1]*a[2]+a[3]) == 24) return true;
    if (a[0]*(a[1]*a[2]-a[3]) == 24) return true;
    if (a[0]*(a[1]+a[2]*a[3]) == 24) return true;
    if (a[0]*(a[1]+a[2]+a[3]) == 24) return true;
    if (a[0]*(a[1]+a[2]-a[3]) == 24) return true;
    if (a[0]*(a[1]-a[2]*a[3]) == 24) return true;
    if (a[0]*(a[1]-a[2]+a[3]) == 24) return true;
    if (a[0]*(a[1]-a[2]-a[3]) == 24) return true;
    if (a[0]+(a[1]*a[2]*a[3]) == 24) return true;
    if (a[0]+(a[1]*a[2]+a[3]) == 24) return true;
    if (a[0]+(a[1]*a[2]-a[3]) == 24) return true;
    if (a[0]+(a[1]+a[2]*a[3]) == 24) return true;
    if (a[0]+(a[1]+a[2]+a[3]) == 24) return true;
    if (a[0]+(a[1]+a[2]-a[3]) == 24) return true;
    if (a[0]+(a[1]-a[2]*a[3]) == 24) return true;
    if (a[0]+(a[1]-a[2]+a[3]) == 24) return true;
    if (a[0]+(a[1]-a[2]-a[3]) == 24) return true;
    if (a[0]-(a[1]*a[2]*a[3]) == 24) return true;
    if (a[0]-(a[1]*a[2]+a[3]) == 24) return true;
    if (a[0]-(a[1]*a[2]-a[3]) == 24) return true;
    if (a[0]-(a[1]+a[2]*a[3]) == 24) return true;
    if (a[0]-(a[1]+a[2]+a[3]) == 24) return true;
    if (a[0]-(a[1]+a[2]-a[3]) == 24) return true;
    if (a[0]-(a[1]-a[2]*a[3]) == 24) return true;
    if (a[0]-(a[1]-a[2]+a[3]) == 24) return true;
    if (a[0]-(a[1]-a[2]-a[3]) == 24) return true;
    if (a[0]*a[1]*(a[2]*a[3]) == 24) return true;
    if (a[0]*a[1]*(a[2]+a[3]) == 24) return true;
    if (a[0]*a[1]*(a[2]-a[3]) == 24) return true;
    if (a[0]*a[1]+(a[2]*a[3]) == 24) return true;
    if (a[0]*a[1]+(a[2]+a[3]) == 24) return true;
    if (a[0]*a[1]+(a[2]-a[3]) == 24) return true;
    if (a[0]*a[1]-(a[2]*a[3]) == 24) return true;
    if (a[0]*a[1]-(a[2]+a[3]) == 24) return true;
    if (a[0]*a[1]-(a[2]-a[3]) == 24) return true;
    if (a[0]+a[1]*(a[2]*a[3]) == 24) return true;
    if (a[0]+a[1]*(a[2]+a[3]) == 24) return true;
    if (a[0]+a[1]*(a[2]-a[3]) == 24) return true;
    if (a[0]+a[1]+(a[2]*a[3]) == 24) return true;
    if (a[0]+a[1]+(a[2]+a[3]) == 24) return true;
    if (a[0]+a[1]+(a[2]-a[3]) == 24) return true;
    if (a[0]+a[1]-(a[2]*a[3]) == 24) return true;
    if (a[0]+a[1]-(a[2]+a[3]) == 24) return true;
    if (a[0]+a[1]-(a[2]-a[3]) == 24) return true;
    if (a[0]-a[1]*(a[2]*a[3]) == 24) return true;
    if (a[0]-a[1]*(a[2]+a[3]) == 24) return true;
    if (a[0]-a[1]*(a[2]-a[3]) == 24) return true;
    if (a[0]-a[1]+(a[2]*a[3]) == 24) return true;
    if (a[0]-a[1]+(a[2]+a[3]) == 24) return true;
    if (a[0]-a[1]+(a[2]-a[3]) == 24) return true;
    if (a[0]-a[1]-(a[2]*a[3]) == 24) return true;
    if (a[0]-a[1]-(a[2]+a[3]) == 24) return true;
    if (a[0]-a[1]-(a[2]-a[3]) == 24) return true;
    return false;
}

bool TwoPar() {
    if ((a[0]*a[1])*(a[2]*a[3]) == 24) return true;
    if ((a[0]*a[1])*(a[2]+a[3]) == 24) return true;
    if ((a[0]*a[1])*(a[2]-a[3]) == 24) return true;
    if ((a[0]*a[1])+(a[2]*a[3]) == 24) return true;
    if ((a[0]*a[1])+(a[2]+a[3]) == 24) return true;
    if ((a[0]*a[1])+(a[2]-a[3]) == 24) return true;
    if ((a[0]*a[1])-(a[2]*a[3]) == 24) return true;
    if ((a[0]*a[1])-(a[2]+a[3]) == 24) return true;
    if ((a[0]*a[1])-(a[2]-a[3]) == 24) return true;
    if ((a[0]+a[1])*(a[2]*a[3]) == 24) return true;
    if ((a[0]+a[1])*(a[2]+a[3]) == 24) return true;
    if ((a[0]+a[1])*(a[2]-a[3]) == 24) return true;
    if ((a[0]+a[1])+(a[2]*a[3]) == 24) return true;
    if ((a[0]+a[1])+(a[2]+a[3]) == 24) return true;
    if ((a[0]+a[1])+(a[2]-a[3]) == 24) return true;
    if ((a[0]+a[1])-(a[2]*a[3]) == 24) return true;
    if ((a[0]+a[1])-(a[2]+a[3]) == 24) return true;
    if ((a[0]+a[1])-(a[2]-a[3]) == 24) return true;
    if ((a[0]-a[1])*(a[2]*a[3]) == 24) return true;
    if ((a[0]-a[1])*(a[2]+a[3]) == 24) return true;
    if ((a[0]-a[1])*(a[2]-a[3]) == 24) return true;
    if ((a[0]-a[1])+(a[2]*a[3]) == 24) return true;
    if ((a[0]-a[1])+(a[2]+a[3]) == 24) return true;
    if ((a[0]-a[1])+(a[2]-a[3]) == 24) return true;
    if ((a[0]-a[1])-(a[2]*a[3]) == 24) return true;
    if ((a[0]-a[1])-(a[2]+a[3]) == 24) return true;
    if ((a[0]-a[1])-(a[2]-a[3]) == 24) return true;
    return false;
}

bool ThreePar() {
    if (((a[0]*a[1])*a[2])*a[3] == 24) return true;
    if (((a[0]*a[1])*a[2])+a[3] == 24) return true;
    if (((a[0]*a[1])*a[2])-a[3] == 24) return true;
    if (((a[0]*a[1])+a[2])*a[3] == 24) return true;
    if (((a[0]*a[1])+a[2])+a[3] == 24) return true;
    if (((a[0]*a[1])+a[2])-a[3] == 24) return true;
    if (((a[0]*a[1])-a[2])*a[3] == 24) return true;
    if (((a[0]*a[1])-a[2])+a[3] == 24) return true;
    if (((a[0]*a[1])-a[2])-a[3] == 24) return true;
    if (((a[0]+a[1])*a[2])*a[3] == 24) return true;
    if (((a[0]+a[1])*a[2])+a[3] == 24) return true;
    if (((a[0]+a[1])*a[2])-a[3] == 24) return true;
    if (((a[0]+a[1])+a[2])*a[3] == 24) return true;
    if (((a[0]+a[1])+a[2])+a[3] == 24) return true;
    if (((a[0]+a[1])+a[2])-a[3] == 24) return true;
    if (((a[0]+a[1])-a[2])*a[3] == 24) return true;
    if (((a[0]+a[1])-a[2])+a[3] == 24) return true;
    if (((a[0]+a[1])-a[2])-a[3] == 24) return true;
    if (((a[0]-a[1])*a[2])*a[3] == 24) return true;
    if (((a[0]-a[1])*a[2])+a[3] == 24) return true;
    if (((a[0]-a[1])*a[2])-a[3] == 24) return true;
    if (((a[0]-a[1])+a[2])*a[3] == 24) return true;
    if (((a[0]-a[1])+a[2])+a[3] == 24) return true;
    if (((a[0]-a[1])+a[2])-a[3] == 24) return true;
    if (((a[0]-a[1])-a[2])*a[3] == 24) return true;
    if (((a[0]-a[1])-a[2])+a[3] == 24) return true;
    if (((a[0]-a[1])-a[2])-a[3] == 24) return true;
    if ((a[0]*(a[1]*a[2]))*a[3] == 24) return true;
    if ((a[0]*(a[1]*a[2]))+a[3] == 24) return true;
    if ((a[0]*(a[1]*a[2]))-a[3] == 24) return true;
    if ((a[0]*(a[1]+a[2]))*a[3] == 24) return true;
    if ((a[0]*(a[1]+a[2]))+a[3] == 24) return true;
    if ((a[0]*(a[1]+a[2]))-a[3] == 24) return true;
    if ((a[0]*(a[1]-a[2]))*a[3] == 24) return true;
    if ((a[0]*(a[1]-a[2]))+a[3] == 24) return true;
    if ((a[0]*(a[1]-a[2]))-a[3] == 24) return true;
    if ((a[0]+(a[1]*a[2]))*a[3] == 24) return true;
    if ((a[0]+(a[1]*a[2]))+a[3] == 24) return true;
    if ((a[0]+(a[1]*a[2]))-a[3] == 24) return true;
    if ((a[0]+(a[1]+a[2]))*a[3] == 24) return true;
    if ((a[0]+(a[1]+a[2]))+a[3] == 24) return true;
    if ((a[0]+(a[1]+a[2]))-a[3] == 24) return true;
    if ((a[0]+(a[1]-a[2]))*a[3] == 24) return true;
    if ((a[0]+(a[1]-a[2]))+a[3] == 24) return true;
    if ((a[0]+(a[1]-a[2]))-a[3] == 24) return true;
    if ((a[0]-(a[1]*a[2]))*a[3] == 24) return true;
    if ((a[0]-(a[1]*a[2]))+a[3] == 24) return true;
    if ((a[0]-(a[1]*a[2]))-a[3] == 24) return true;
    if ((a[0]-(a[1]+a[2]))*a[3] == 24) return true;
    if ((a[0]-(a[1]+a[2]))+a[3] == 24) return true;
    if ((a[0]-(a[1]+a[2]))-a[3] == 24) return true;
    if ((a[0]-(a[1]-a[2]))*a[3] == 24) return true;
    if ((a[0]-(a[1]-a[2]))+a[3] == 24) return true;
    if ((a[0]-(a[1]-a[2]))-a[3] == 24) return true;
    if (a[0]*((a[1]*a[2])*a[3]) == 24) return true;
    if (a[0]*((a[1]*a[2])+a[3]) == 24) return true;
    if (a[0]*((a[1]*a[2])-a[3]) == 24) return true;
    if (a[0]*((a[1]+a[2])*a[3]) == 24) return true;
    if (a[0]*((a[1]+a[2])+a[3]) == 24) return true;
    if (a[0]*((a[1]+a[2])-a[3]) == 24) return true;
    if (a[0]*((a[1]-a[2])*a[3]) == 24) return true;
    if (a[0]*((a[1]-a[2])+a[3]) == 24) return true;
    if (a[0]*((a[1]-a[2])-a[3]) == 24) return true;
    if (a[0]+((a[1]*a[2])*a[3]) == 24) return true;
    if (a[0]+((a[1]*a[2])+a[3]) == 24) return true;
    if (a[0]+((a[1]*a[2])-a[3]) == 24) return true;
    if (a[0]+((a[1]+a[2])*a[3]) == 24) return true;
    if (a[0]+((a[1]+a[2])+a[3]) == 24) return true;
    if (a[0]+((a[1]+a[2])-a[3]) == 24) return true;
    if (a[0]+((a[1]-a[2])*a[3]) == 24) return true;
    if (a[0]+((a[1]-a[2])+a[3]) == 24) return true;
    if (a[0]+((a[1]-a[2])-a[3]) == 24) return true;
    if (a[0]-((a[1]*a[2])*a[3]) == 24) return true;
    if (a[0]-((a[1]*a[2])+a[3]) == 24) return true;
    if (a[0]-((a[1]*a[2])-a[3]) == 24) return true;
    if (a[0]-((a[1]+a[2])*a[3]) == 24) return true;
    if (a[0]-((a[1]+a[2])+a[3]) == 24) return true;
    if (a[0]-((a[1]+a[2])-a[3]) == 24) return true;
    if (a[0]-((a[1]-a[2])*a[3]) == 24) return true;
    if (a[0]-((a[1]-a[2])+a[3]) == 24) return true;
    if (a[0]-((a[1]-a[2])-a[3]) == 24) return true;
    if (a[0]*(a[1]*(a[2]*a[3])) == 24) return true;
    if (a[0]*(a[1]*(a[2]+a[3])) == 24) return true;
    if (a[0]*(a[1]*(a[2]-a[3])) == 24) return true;
    if (a[0]*(a[1]+(a[2]*a[3])) == 24) return true;
    if (a[0]*(a[1]+(a[2]+a[3])) == 24) return true;
    if (a[0]*(a[1]+(a[2]-a[3])) == 24) return true;
    if (a[0]*(a[1]-(a[2]*a[3])) == 24) return true;
    if (a[0]*(a[1]-(a[2]+a[3])) == 24) return true;
    if (a[0]*(a[1]-(a[2]-a[3])) == 24) return true;
    if (a[0]+(a[1]*(a[2]*a[3])) == 24) return true;
    if (a[0]+(a[1]*(a[2]+a[3])) == 24) return true;
    if (a[0]+(a[1]*(a[2]-a[3])) == 24) return true;
    if (a[0]+(a[1]+(a[2]*a[3])) == 24) return true;
    if (a[0]+(a[1]+(a[2]+a[3])) == 24) return true;
    if (a[0]+(a[1]+(a[2]-a[3])) == 24) return true;
    if (a[0]+(a[1]-(a[2]*a[3])) == 24) return true;
    if (a[0]+(a[1]-(a[2]+a[3])) == 24) return true;
    if (a[0]+(a[1]-(a[2]-a[3])) == 24) return true;
    if (a[0]-(a[1]*(a[2]*a[3])) == 24) return true;
    if (a[0]-(a[1]*(a[2]+a[3])) == 24) return true;
    if (a[0]-(a[1]*(a[2]-a[3])) == 24) return true;
    if (a[0]-(a[1]+(a[2]*a[3])) == 24) return true;
    if (a[0]-(a[1]+(a[2]+a[3])) == 24) return true;
    if (a[0]-(a[1]+(a[2]-a[3])) == 24) return true;
    if (a[0]-(a[1]-(a[2]*a[3])) == 24) return true;
    if (a[0]-(a[1]-(a[2]+a[3])) == 24) return true;
    if (a[0]-(a[1]-(a[2]-a[3])) == 24) return true;
    return false;
}

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int ans = 100;
    cin >> a[0] >> a[1] >> a[2] >> a[3];
    b[0] = a[0], b[1] = a[1], b[2] = a[2], b[3] = a[3];
    if (ZeroPar()) ans = min(ans, 0);
    if (OnePar()) ans = min(ans, 1);
    if (TwoPar()) ans = min(ans, 2);
    if (ThreePar()) ans = min(ans, 3);
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (i == j) continue;
            swap(a[i], a[j]);
            if (ZeroPar()) ans = min(ans, 2);
            if (OnePar()) ans = min(ans, 3);
            if (TwoPar()) ans = min(ans, 4);
            if (ThreePar()) ans = min(ans, 5);
            swap(a[i], a[j]);
        }
    }
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < 4; k++) {
                if (i == j || i == k) continue;
                if (j == k) continue;
                swap(a[i], a[j]); swap(a[j], a[i]);
                if (ZeroPar()) ans = min(ans, 4);
                if (OnePar()) ans = min(ans, 5);
                if (TwoPar()) ans = min(ans, 6);
                if (ThreePar()) ans = min(ans, 7);
                a[0]=b[0], a[1]=b[1], a[2]=b[2];
            }
        }
    }
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < 4; k++) {
                for (int l = 0; l < 4; l++) {
                    if (i == j || i == k || i == l) continue;
                    if (j == k || j == l) continue;
                    if (k == l) continue;
                    swap(a[i], a[j]); swap(a[k], a[l]);
                    if (ZeroPar()) ans = min(ans, 4);
                    if (OnePar()) ans = min(ans, 5);
                    if (TwoPar()) ans = min(ans, 6);
                    if (ThreePar()) ans = min(ans, 7);
                    swap(a[i], a[j]); swap(a[k], a[l]);
                }
            }
        }
    }
    if (ans == 100)
        ans = 0;
    cout << ans << '\n';
    return 0;
}
