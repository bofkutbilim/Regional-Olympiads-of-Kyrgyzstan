#include <bits/stdc++.h>

using namespace std;

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int n;
  cin >> n;
  vector<pair<int, int> > a(n);
  for (int i = 0; i < n; i++) {
    cin >> a[i].first;
  }
  for (int i = 0; i < n; i++) {
    cin >> a[i].second;
  }
  sort(a.begin(), a.end());
  int ans = 0;
  while (!a.empty()) {
    pair<int, int> v = a[0];
    int time = a[0].first + 80;
    ans += time;
    a[0].first = 60, a[0].second--;
    if (a.size() > 1) {
      a[1].first = max(a[1].first - time, 0);
    }
    for (int i = 2; i < a.size(); i++) {
      a[i].first = max(a[i].first - time, a[i - 1].first + 1);
    }
    if (a[0].second == 0)
      a.erase(a.begin());
    sort(a.begin(), a.end());
  }
  cout << ans;
  return 0;
}
