// bismi allah
#include <iostream>
#include <cmath>

using namespace std;

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    long long m, o, a, b;
    cin >> m >> o >> a >> b;
    for (long long x = 0; x <= m; x++) {
        for (long long y = 0; y <= m; y++) {
            long long s1 = o - (x * x + y * y);
            long long s2 = a - ((x - m) * (x - m) + y * y);
            long long s3 = b - (x * x + (y - m) * (y - m));
            if (s1 == s2 && s2 == s3)
                return cout << x << ' ' << y << ' ' << round(sqrt(s1+.0)), 0;
        }
    }
    return 0;
