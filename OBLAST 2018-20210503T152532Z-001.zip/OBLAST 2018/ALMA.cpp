#include <bits/stdc++.h>

using namespace std;

int main() {
    int q, ans = 2e9;
    cin >> q;
    /// with horse
    ans = min(ans, (q+19)/20+(q+19)/20-1);
    /// with donkey
    ans = min(ans, ((q+199)/200)*5+((q+199)/200-1)*3);
    ///with both of them
    int a = q/200, b = q%200;
    if (b == 0) {
        ans = min(ans, a*5+(a-1)*3);
    } else {
        ans = min(ans, (b+19)/20+(b+19)/20-1+a*5+a*3);
    }
    cout << ans << '\n';
    return 0;
}
