#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    cin >> n;
    long long ans = 0;
    ans += n;
    ans += (n-1)*n;
    for (int i = 1; i <= n; i++) {
        int m = (n-i);
        ans += (m-1)*m/2;
    }

    cout << ans << '\n';
    return 0;
}
