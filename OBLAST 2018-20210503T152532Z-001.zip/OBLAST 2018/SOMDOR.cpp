#include <bits/stdc++.h>

using namespace std;

int main() {
    int a, b, s;
    cin >> a >> b >> s;
    for (int i = 0; i <= a; i++) {
        for (int j = 0; j <= b; j++) {
            if (i*3 + j*10 == s) {
                cout << i + j << '\n';
                return 0;
            }
        }
    }
    cout << "0\n";
    return 0;
}
