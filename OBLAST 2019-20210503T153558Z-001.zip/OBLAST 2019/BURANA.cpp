#include <bits/stdc++.h>

using namespace std;

int mas[300];

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    int a, b, t, ans = 0;
    cin >> a >> t >> b;
    int i = 1;
    while (a--) {
        while (mas[i]) i++;
        mas[i] = 1;
        mas[i + 6] = 1;
    }
    i = t + 1;
    while (b--) {
        while (mas[i]) i++;
        mas[i] = 1;
        mas[i + 6] = 1;
    }
    for (int i = 0; i < 300; i++) {
        if (mas[i]) ans = i;
    }
    cout << ans << '\n';
    return 0;
}
